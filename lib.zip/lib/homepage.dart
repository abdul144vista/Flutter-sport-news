import 'package:flutter/material.dart';
import 'package:google_nav_bar/google_nav_bar.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

  int currentIndex = 0;


class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: GNav(
      
        backgroundColor: Colors.black,
        color: Colors.white,
        activeColor: Colors.white,
        gap: 10,
        tabs: const [
          GButton(
            icon: Icons.sports_soccer,
            text: 'Football',
          ),
          GButton(
            icon: Icons.sports_basketball_outlined,
            text: 'Basketball',
          ),
          GButton(
            icon: Icons.sports_mma_outlined,
            text: 'MMA',
          ),
          GButton(
            icon: Icons.sports_score_outlined,
            text: 'F1',
          ),
        ],
      ),
    );
  }
}
