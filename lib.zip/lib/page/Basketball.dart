import 'package:flutter/material.dart';

class Basketball extends StatelessWidget {
  const Basketball({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Basketball',
      home: Scaffold(
        appBar: AppBar(
          title: const Text('Basketball'),
        ),
        body: const Center(
          child: Text('Hello World'),
        ),
      ),
    );
  }
}
